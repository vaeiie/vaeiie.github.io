# cine archive ♡ — GitHub Pages starter

Your vintage-inspired, brown-and-ivory movie blog. It is built with plain HTML and CSS, so you do not need to install software or write code.

## Publish it on GitHub Pages (no coding)

1. Download and unzip `cine-archive-vintage-github-pages.zip` on your computer.
2. Sign in at https://github.com (or create an account).
3. Click the **+** in the top-right, then **New repository**.
4. For the repository name, enter `YOUR-USERNAME.github.io`, replacing `YOUR-USERNAME` with your exact GitHub username. Set it to **Public**, then click **Create repository**.
5. Inside the new repository, choose **Add file → Upload files**.
6. Open the unzipped folder on your computer and drag **index.html** into the upload area. You can also upload `README.md` if you like. Do not upload the ZIP itself.
7. Scroll down and click **Commit changes**.
8. In your repository, open **Settings → Pages**.
9. Under **Build and deployment**, select **Deploy from a branch**. Choose branch **main** and folder **/(root)**, then click **Save**.
10. Wait a few minutes, then visit `https://YOUR-USERNAME.github.io` (use your actual username).

If it does not appear immediately, wait a little and refresh the Pages settings page to check the publishing status.

## Make changes later without coding

1. Open `index.html` in your GitHub repository.
2. Click the pencil icon to edit.
3. Use your browser's Find feature (Ctrl+F on Windows) to locate a film title or sentence.
4. Replace only the words between the HTML tags; keep the angle-bracket code around them intact.
5. Click **Commit changes**. Your published site will update after GitHub Pages rebuilds it.

The poster artwork in this starter is made from CSS gradients and text, not official movie posters. If you add images later, use images you have permission to publish.

**Privacy note:** GitHub Pages sites are public. Do not publish your home address, school, personal phone number, or other private information.
